/** Automatically generated file. DO NOT MODIFY */
package com.learn2crack.speech;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}